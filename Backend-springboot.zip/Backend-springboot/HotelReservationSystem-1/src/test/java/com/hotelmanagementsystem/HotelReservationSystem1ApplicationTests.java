package com.hotelmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelReservationSystem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
