package com.hotelmanagementsystem.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name="booking_table")
public class Booking {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="booking_id")
	private long bookingId;
	
	@Column(name="hotel_name")
	private String hotelName;
		
	@Column(name="room_id")
	private long roomId;
	
	@Column(name="room_type")
	private String roomType;
	
	@Column(name="room_number")
	private String roomNumber;
	
	@Column(name="room_price")
	private int roomPrice;	

	@OneToMany(mappedBy="booking")
	@JsonIgnore
	private List<Hotel> hotel;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="customerId")
	private Customer customer;
	
	
public Booking() {
		
	}


public long getBookingId() {
	return bookingId;
}


public void setBookingId(long bookingId) {
	this.bookingId = bookingId;
}


public String getHotelName() {
	return hotelName;
}


public void setHotelName(String hotelName) {
	this.hotelName = hotelName;
}


public long getRoomId() {
	return roomId;
}


public void setRoomId(long roomId) {
	this.roomId = roomId;
}


public String getRoomType() {
	return roomType;
}


public void setRoomType(String roomType) {
	this.roomType = roomType;
}


public String getRoomNumber() {
	return roomNumber;
}


public void setRoomNumber(String roomNumber) {
	this.roomNumber = roomNumber;
}


public int getRoomPrice() {
	return roomPrice;
}


public void setRoomPrice(int roomPrice) {
	this.roomPrice = roomPrice;
}


public List<Hotel> getHotel() {
	return hotel;
}


public void setHotel(List<Hotel> hotel) {
	this.hotel = hotel;
}


public Customer getCustomer() {
	return customer;
}


public void setCustomer(Customer customer) {
	this.customer = customer;
}


public Booking(long bookingId, String hotelName, long roomId, String roomType, String roomNumber, int roomPrice,
		List<Hotel> hotel, Customer customer) {
	super();
	this.bookingId = bookingId;
	this.hotelName = hotelName;
	this.roomId = roomId;
	this.roomType = roomType;
	this.roomNumber = roomNumber;
	this.roomPrice = roomPrice;
	this.hotel = hotel;
	this.customer = customer;
}





}
