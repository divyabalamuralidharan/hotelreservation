package com.hotelmanagementsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotelmanagementsystem.model.Room;

public interface RoomRepository extends JpaRepository<Room,Long>{

}
