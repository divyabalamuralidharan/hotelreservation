import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Hotel } from '../model/hotel';


@Injectable({
  providedIn: 'root'
})
export class HotelService {

  addHotURL : string;
  getHotURL : string;
  
  deleteHotUrl : string;

  constructor(private http : HttpClient) {

    this.addHotURL = 'http://localhost:8080/api/hotel/register';
    this.getHotURL = 'http://localhost:8080/api/hotel/getAll';
   
    this.deleteHotUrl = 'http://localhost:8080/api/hotel/deleteHotelById';

   }

   addHotel(emp : Hotel): Observable<Hotel> {
     return this.http.post<Hotel>(this.addHotURL,emp);
   }

   getAllHotel(): Observable<Hotel[]>{
     return this.http.get<Hotel[]>(this.getHotURL);
   }

  

   deleteHotel(emp : Hotel) : Observable<Hotel> {
     return this.http.delete<Hotel>(this.deleteHotUrl+'/'+emp.id);
   }
  

}
