import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../model/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  addCusURL : string;
  getCusURL : string;
  // updateCusUrl : string;
  deleteCusUrl : string;

  constructor(private http : HttpClient) {

    this.addCusURL ='http://localhost:8080/api/customers/register';
    this.getCusURL = 'http://localhost:8080/api/customers/getAll';
    // this.updateCusUrl ='http://localhost:8080/api/customers';
    this.deleteCusUrl ='http://localhost:8080/api/customers/deleteCustomerById';

   }

   addCustomer(emp : Customer): Observable<Customer> {
     return this.http.post<Customer>(this.addCusURL,emp);
   }

   getAllCustomer(): Observable<Customer[]>{
     return this.http.get<Customer[]>(this.getCusURL);
   }

  //  updateCustomer(emp :Customer) : Observable<Customer>{
  //    return this.http.put<Customer>(this.updateCusUrl, emp);
  //  }

   deleteCustomer(emp : Customer) : Observable<Customer> {
     return this.http.delete<Customer>(this.deleteCusUrl+'/'+emp.customerId);
   }
}
