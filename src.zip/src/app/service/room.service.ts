import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Room } from '../model/room';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  addRoomURL : string;
  getRoomURL : string;
  
  deleteRoomUrl : string;

  constructor(private http : HttpClient) {

    this.addRoomURL = 'http://localhost:8080/api/room/add';
    this.getRoomURL = 'http://localhost:8080/api/room/getAll';
   
    this.deleteRoomUrl = 'http://localhost:8080/api/room/deleteRoomById';

   }

   addRoom(emp : Room): Observable<Room> {
     return this.http.post<Room>(this.addRoomURL,emp);
   }

   getAllRoom(): Observable<Room[]>{
     return this.http.get<Room[]>(this.getRoomURL);
   }

 

   deleteRoom(emp : Room) : Observable<Room> {
     return this.http.delete<Room>(this.deleteRoomUrl+'/'+emp.roomId);
   }
  

}

