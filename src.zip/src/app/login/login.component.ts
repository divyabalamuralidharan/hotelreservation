import { Component,OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RegistrationService } from '../registration.service';
import { Admin } from '../admin';
import { from, Observable } from 'rxjs';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   admin=new Admin();
   msg='';

constructor(private _service :RegistrationService,private _router:Router){

  }
ngOnInit(){

} 

gotoregistration(){
  this._router.navigate(['/registration'])
}
loginAdmin(){
this._service.loginFromRemote(this.admin).subscribe(
  data =>{
    console.log("response recieved"),
  this._router.navigate(['/loginsucess'])
  },
  error =>{
    console.log("exception occured");
 this. msg="bad credential,please enter valid emailid and password";
  }
)
}


}
