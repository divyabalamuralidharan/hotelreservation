import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms'
import { Hotel } from 'src/app/model/hotel';
import { HotelService } from 'src/app/service/hotel.service';

@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css']
})
export class HotelComponent {
  hotDetail !: FormGroup;
  hotObj : Hotel= new Hotel();
  hotList : Hotel[] = [];

  constructor(private formBuilder : FormBuilder, private hotService : HotelService) { }

  ngOnInit(): void {

    this.getAllHotel();

    this.hotDetail = this.formBuilder.group({
      id : [''],
      hotelName:['']
    
    });    

  }

  addHotel() {
    console.log(this.hotDetail);
    this.hotObj.id = this.hotDetail.value.id;
    this.hotObj.hotelName = this.hotDetail.value.hotelName;
   

    this.hotService.addHotel(this.hotObj).subscribe(res=>{
        console.log(res);
        this.getAllHotel();
    },err=>{
        console.log(err);
    });

  }

  getAllHotel() {
    this.hotService.getAllHotel().subscribe(res=>{
        this.hotList = res;
    },err=>{
      console.log("error while fetching data.")
    });
  }

  editHotel(emp : Hotel) {
    this.hotDetail.controls['id'].setValue(emp.id);
    this.hotDetail.controls['hotelName'].setValue(emp.hotelName);
   

  }

  

  deleteHotel(emp : Hotel) {

    this.hotService.deleteHotel(emp).subscribe(res=>{
      console.log(res);
      alert('Employee deleted successfully');
      this.getAllHotel();
    },err => {
      console.log(err);
    });

  }

}


