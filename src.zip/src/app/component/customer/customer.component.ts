import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms'
import { Customer } from 'src/app/model/customer';
import { CustomerService } from 'src/app/service/customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  cusDetail !: FormGroup;
  cusObj : Customer = new Customer();
  cusList : Customer[] = [];

  constructor(private formBuilder : FormBuilder, private cusService : CustomerService) { }

  ngOnInit(): void {

    this.getAllCustomer();

    this.cusDetail = this.formBuilder.group({
     customerId:[''],
      firstName:[''],
      lastName:[''],
      phoneNumber:[''],
      emailId:[''],
      Password:['']
    });    

  }

  addCustomer() {
    console.log(this.cusDetail);
    this.cusObj.customerId = this.cusDetail.value.customerId;
    this.cusObj.firstName = this.cusDetail.value.firstName;
    this.cusObj.lastName = this.cusDetail.value.lastName;
    this.cusObj.phoneNumber = this.cusDetail.value.phoneNumber;
    this.cusObj.emailId = this.cusDetail.value.emailId;
    this.cusObj.Password = this.cusDetail.value.Password;


    this.cusService.addCustomer(this.cusObj).subscribe(res=>{
        console.log(res);
        this.getAllCustomer();
    },err=>{
        console.log(err);
    });

  }

  getAllCustomer() {
    this.cusService.getAllCustomer().subscribe(res=>{
        this.cusList = res;
    },err=>{
      console.log("error while fetching data.")
    });
  }

  editCustomer(emp : Customer) {
    this.cusDetail.controls['customerId'].setValue(emp.customerId);
    this.cusDetail.controls['firstName'].setValue(emp.firstName);
    this.cusDetail.controls['lastName'].setValue(emp.lastName);
    this.cusDetail.controls['phoneNumber'].setValue(emp.phoneNumber);
    this.cusDetail.controls['emailId'].setValue(emp.emailId);
    this.cusDetail.controls['Password'].setValue(emp.Password);

  }

  // updateCustomer() {

  //   this.cusObj.customerId = this.cusDetail.value.customerId;
  //   this.cusObj.firstName = this.cusDetail.value.firstName;
  //   this.cusObj.lastName = this.cusDetail.value.lastName;
  //   this.cusObj.phoneNumber = this.cusDetail.value.phoneNumber;
  //   this.cusObj.emailId = this.cusDetail.value.emailId;
  //   this.cusObj.Password = this.cusDetail.value.Password;

  //   this.cusService.updateCustomer(this.cusObj).subscribe(res=>{
  //     console.log(res);
  //     this.getAllCustomer();
  //   },err=>{
  //     console.log(err);
  //   })

  // }

  deleteCustomer(emp : Customer) {

    this.cusService.deleteCustomer(emp).subscribe(res=>{
      console.log(res);
      alert('Employee deleted successfully');
      this.getAllCustomer();
    },err => {
      console.log(err);
    });

  }
}