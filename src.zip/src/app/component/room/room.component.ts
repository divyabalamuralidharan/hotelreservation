import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms'
import { Room } from 'src/app/model/room';
import { RoomService } from 'src/app/service/room.service';


@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent {
  roomDetail !: FormGroup;
  roomObj : Room = new Room();
  roomList : Room[] = [];

  constructor(private formBuilder : FormBuilder, private roomService : RoomService) { }

  ngOnInit(): void {

    this.getAllRoom();

    this.roomDetail = this.formBuilder.group({
      roomId:[''],
      roomNumber:[''],
      roomType:[''],
      roomPrice:[''],
    });    

  }

  addRoom() {
    console.log(this.roomDetail);
    this.roomObj.roomId = this.roomDetail.value.roomId;
    this.roomObj.roomNumber = this.roomDetail.value.roomNumber;
    this.roomObj.roomType = this.roomDetail.value.roomType;
    this.roomObj.roomPrice = this.roomDetail.value.roomPrice;

    this.roomService.addRoom(this.roomObj).subscribe(res=>{
        console.log(res);
        this.getAllRoom();
    },err=>{
        console.log(err);
    });

  }

  getAllRoom() {
    this.roomService.getAllRoom().subscribe(res=>{
        this.roomList = res;
    },err=>{
      console.log("error while fetching data.")
    });
  }

  editRoom(emp : Room) {
    this.roomDetail.controls['roomId'].setValue(emp.roomId);
    this.roomDetail.controls['roomNumber'].setValue(emp.roomNumber);
    this.roomDetail.controls['roomType'].setValue(emp.roomType);
    this.roomDetail.controls['roomPrice'].setValue(emp.roomPrice);

  }

  

  deleteRoom(emp : Room) {

    this.roomService.deleteRoom(emp).subscribe(res=>{
      console.log(res);
      alert('Employee deleted successfully');
      this.getAllRoom();
    },err => {
      console.log(err);
    });

  }


}
