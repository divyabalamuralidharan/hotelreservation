import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms'
import { Booking } from 'src/app/booking';
import { BookingService } from 'src/app/services/booking.service';


@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  bookingDetail !: FormGroup;
  bookingObj : Booking= new Booking();
  bookingList : Booking[] = [];

  constructor(private formBuilder : FormBuilder, private bookingService : BookingService) { }

  ngOnInit(): void {

    this.getAllBooking();

    this.bookingDetail = this.formBuilder.group({
      bookingId: [''],
      hotelName: [''],
      roomId: [''],
      roomType: [''],
      roomNumber:[''],
      roomPrice:['']
    });    

  }

  addBooking() {
    console.log(this.bookingDetail);
    this.bookingObj.bookingId= this.bookingDetail.value.bookingId;
    this.bookingObj.hotelName = this.bookingDetail.value.hotelName;
    this.bookingObj.roomId = this.bookingDetail.value.roomId;
    this.bookingObj.roomType = this.bookingDetail.value.roomType;
    this.bookingObj.roomNumber = this.bookingDetail.value.roomNumber;
    this.bookingObj.roomPrice = this.bookingDetail.value.roomPrice;

    this.bookingService.addBooking(this.bookingObj).subscribe(res=>{
        console.log(res);
        this.getAllBooking();
    },err=>{
        console.log(err);
    });

  }

  getAllBooking() {
    this.bookingService.getAllBooking().subscribe(res=>{
        this.bookingList = res;
    },err=>{
      console.log("error while fetching data.")
    });
  }

  editBooking(emp : Booking) {
    this.bookingDetail.controls['bookingId'].setValue(emp.bookingId);
    this.bookingDetail.controls['hotelName'].setValue(emp.hotelName);
    this.bookingDetail.controls['roomId'].setValue(emp.roomId);
    this.bookingDetail.controls['roomType'].setValue(emp.roomType);
    this.bookingDetail.controls['roomNumber'].setValue(emp.roomNumber);
    this.bookingDetail.controls['roomPrice'].setValue(emp.roomPrice);

  }

  
  deleteBooking(emp : Booking) {

    this.bookingService.deleteBooking(emp).subscribe(res=>{
      console.log(res);
      alert('Employee deleted successfully');
      this.getAllBooking();
    },err => {
      console.log(err);
    });

  }


}
