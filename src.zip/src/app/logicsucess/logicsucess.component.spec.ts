import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogicsucessComponent } from './logicsucess.component';

describe('LogicsucessComponent', () => {
  let component: LogicsucessComponent;
  let fixture: ComponentFixture<LogicsucessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LogicsucessComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LogicsucessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
