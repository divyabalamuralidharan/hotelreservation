import { Component,OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';



@Component({
  selector: 'app-logicsucess',
  templateUrl: './logicsucess.component.html',
  styleUrls: ['./logicsucess.component.css']
})
export class LogicsucessComponent implements OnInit{
  constructor(private _router:Router){
  
  }
 ngOnInit(): void {
 }
 gotocustomer(){
  this._router.navigate(['/customer'])
 }
 gotohotel(){
  this._router.navigate(['/hotel']);
 }
 gotoroom(){
  this._router.navigate(['/room'])
 }
 gotobooking(){
  this._router.navigate(['/booking'])
 }
 gotologic(){
  this._router.navigate(['/login'])
 }
}

  


