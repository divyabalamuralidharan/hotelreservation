import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LogicsucessComponent } from './logicsucess/logicsucess.component';
import { RegistrationComponent } from './registration/registration.component';
import { BookingComponent } from './component/booking/booking.component';
import { CustomerComponent } from './component/customer/customer.component';
import { HotelComponent } from './component/hotel/hotel.component';
import { RoomComponent } from './component/room/room.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
   
    LogicsucessComponent,
        RegistrationComponent,
        BookingComponent,
        CustomerComponent,
        HotelComponent,
        RoomComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule
   ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
