export class Booking {
    bookingId!:number;
    hotelName!:string;
    roomId!:number;
    roomType!:string;
    roomNumber!:string;
    roomPrice!:number
  
}
