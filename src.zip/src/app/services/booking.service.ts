import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Booking } from '../booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  addBookingURL : string;
  getBookingURL : string;
  
  deleteBookingUrl : string;

  constructor(private http : HttpClient) {

    this.addBookingURL = 'http://localhost:8080/api/booking/add';
    this.getBookingURL = 'http://localhost:8080/api/booking/getAll';
   
    this.deleteBookingUrl = 'http://localhost:8080/api/booking/deleteBookingById';

   }

   addBooking(emp : Booking): Observable<Booking> {
     return this.http.post<Booking>(this.addBookingURL,emp);
   }

   getAllBooking(): Observable<Booking[]>{
     return this.http.get<Booking[]>(this.getBookingURL);
   }

  

   deleteBooking(emp : Booking) : Observable<Booking> {
     return this.http.delete<Booking>(this.deleteBookingUrl+'/'+emp.bookingId);
   }
}
