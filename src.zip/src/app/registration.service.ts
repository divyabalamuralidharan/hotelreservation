import { Injectable } from '@angular/core';
import { Admin } from './admin';
import { HttpClient} from  '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private _http : HttpClient) { }
  public loginFromRemote(admin:Admin):Observable<any>{
   return this._http.post<any>("http://localhost:8080/api/admin/login",admin)


  }
  public registerAdminFromRemote(admin:Admin):Observable<any>{
    return this._http.post<any>("http://localhost:8080/api/admin/register",admin)
  }
}
