import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookingComponent } from './component/booking/booking.component';
import { CustomerComponent } from './component/customer/customer.component';
import { HotelComponent } from './component/hotel/hotel.component';
import { RoomComponent } from './component/room/room.component';
import { LogicsucessComponent } from './logicsucess/logicsucess.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
  {path: '',component:LoginComponent},
  {path: 'loginsucess',component:LogicsucessComponent},
  {path: 'registration',component:RegistrationComponent},
  {path: 'login',component:LoginComponent},
  {path: 'customer',component:CustomerComponent},
  {path:'hotel',component:HotelComponent},
  {path:'room',component:RoomComponent},
  {path:'booking',component:BookingComponent},
  {path:'login',component:LoginComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
