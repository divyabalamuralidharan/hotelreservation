export class Admin {
    adminId!:number;
    firstName!:string;
    lastName!:string;
    adminEmailId!:string;
    adminPassword!:string
    constructor(){
        
    }
}
