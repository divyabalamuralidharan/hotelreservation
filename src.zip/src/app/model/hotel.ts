export class Hotel {
    id!:number;
    hotelName!:string;

}
