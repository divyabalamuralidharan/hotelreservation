export class Customer {
    customerId!:number;
    firstName!:string;
    lastName!:string;
    phoneNumber!:string;
    emailId!:string;
    Password!:string;
}
