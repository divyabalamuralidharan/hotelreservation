export class Room {
    roomId!:number;
    roomNumber!:string;
    roomType!:string;
    roomPrice!:number;
}
